<?php
require_once 'config.php';
require_once 'helper_classes.php';

// Array untuk response data
$response = array();

// Query data kabkot
$stmt = $conn->query("SELECT * FROM data_kabkot ORDER BY kabkot_name ASC");
$query = $stmt->fetch_all(MYSQLI_ASSOC);

// Periksa apakah query berhasil
if ($query) {
    // Format ulang nama kabkot
    foreach ($query as $key => $value) {
        $query[$key]['kabkot_name'] = ucwords(strtolower($value['kabkot_name']));
    }

    // Masukkan data ke dalam respons
    $response['wilayah'] = array_map(function ($item) {
        return [
            'id' => $item['id'],
            'kode' => $item['kode_kabkot'],
            'nama' => $item['kabkot_name']
        ];
    }, $query);
} else {
    // Jika query gagal
    $response['wilayah'] = [];
}

// Set header dan keluarkan JSON
header('Content-Type: application/json');
echo json_encode($response);
