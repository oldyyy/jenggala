<?php
require_once 'config.php';
require_once 'helper_classes.php';

// Array for response data
$response = array();

$kode_kecamatan = $_POST['kode_kecamatan'];

// Data Kecamatan
$stmt = $conn->prepare("SELECT * FROM data_keldes WHERE kode_keldes LIKE ? ORDER BY keldes_name ASC");
$stmt->execute([$kode_kecamatan . '%']);
$query = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Periksa apakah query berhasil
if ($query) {
    // Format ulang nama kabkot
    foreach ($query as $key => $value) {
        $query[$key]['keldes_name'] = ucwords(strtolower($value['keldes_name']));
    }

    // Masukkan data ke dalam respons
    $response['wilayah'] = array_map(function ($item) {
        return [
            'id' => $item['id'],
            'kode' => $item['kode_keldes'],
            'nama' => $item['keldes_name']
        ];
    }, $query);
} else {
    // Jika query gagal
    $response['wilayah'] = [];
}

// Set header dan keluarkan JSON
header('Content-Type: application/json');

echo json_encode($response);

?>
