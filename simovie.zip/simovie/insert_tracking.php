<?php
header('Content-Type: application/json');
require_once 'config.php';
require_once 'helper_classes.php';

// Array for response data
$response = array();
$result = new Result();

// Debugging untuk memeriksa input
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validasi apakah semua parameter tersedia
    if (
        isset($_POST['kode_responden']) &&
        isset($_POST['kode_petugas']) &&
        isset($_POST['kode_kegiatan']) &&
        isset($_POST['jam_mulai']) &&
        isset($_POST['jam_selesai']) &&
        isset($_POST['total_waktu']) &&
        isset($_POST['latitude_start']) &&
        isset($_POST['longitude_start']) &&
        isset($_POST['latitude_stop']) &&
        isset($_POST['longitude_stop']) &&
        isset($_POST['kode_status'])
    ) {
        // Ambil data dari POST
        // Ambil data dari POST, dengan nilai default jika keterangan tidak disediakan
        $kode_responden = $_POST['kode_responden'];
        $kode_petugas = $_POST['kode_petugas'];
        $kode_kegiatan = $_POST['kode_kegiatan'];
        $jam_mulai = $_POST['jam_mulai'];
        $jam_selesai = $_POST['jam_selesai'];
        $total_waktu = $_POST['total_waktu'];
        $latitude_start = $_POST['latitude_start'];
        $longitude_start = $_POST['longitude_start'];
        $latitude_stop = $_POST['latitude_stop'];
        $longitude_stop = $_POST['longitude_stop'];
        $kode_status = $_POST['kode_status'];
        $keterangan = isset($_POST['keterangan']) ? $_POST['keterangan'] : null; // Nilai default adalah null

        // Query untuk insert data
        $stmt = $conn->prepare("INSERT INTO monitoring (kode_responden, kode_petugas, kode_kegiatan, jam_mulai, jam_selesai, total_waktu, latitude_start, longitude_start, latitude_stop, longitude_stop, kode_status, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssssssss", $kode_responden, $kode_petugas, $kode_kegiatan, $jam_mulai, $jam_selesai, $total_waktu, $latitude_start, $longitude_start, $latitude_stop, $longitude_stop, $kode_status, $keterangan);

        // Eksekusi query dan cek apakah berhasil
        if ($stmt->execute()) {
            // Update Status Responden
            $sql = "SELECT * FROM master_responden WHERE kode_responden = '$kode_responden'";
            $query = $conn->query($sql);
            $row = $query->fetch_assoc();
            $source_table = $row['source_table'];

            $stmt = $conn->prepare("UPDATE $source_table SET kode_status = ? WHERE kode_responden = ?");
            $stmt->bind_param("ss", $kode_status, $kode_responden);
            $stmt->execute();

            $result->setError(false);
            $result->setMessage('Tracking data inserted successfully');
        } else {
            $result->setError(true);
            $result->setMessage('Failed to insert tracking data');
        }
    } else {
        $result->setError(true);
        $result->setMessage('Missing required fields');
    }
} else {
    $result->setError(true);
    $result->setMessage('Invalid request method');
}

// Format dan kirimkan respons JSON
$response['result']['isError'] = $result->isError();
$response['result']['message'] = $result->getMessage();

// Tambahkan log untuk debugging
error_log(json_encode($response));

// Kirim respons JSON
echo json_encode($response);
?>