<?php
require_once 'config.php';
require_once 'helper_classes.php';

// Array for response data
$response = array();

$kode_kabkot = $_POST['kode_kabkot'];

// Data Kecamatan
$stmt = $conn->prepare("SELECT * FROM data_kec WHERE kode_kecamatan LIKE ? ORDER BY kecamatan_name ASC");
$stmt->execute([$kode_kabkot . '%']);
$query = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Periksa apakah query berhasil
if ($query) {
    // Format ulang nama kabkot
    foreach ($query as $key => $value) {
        $query[$key]['kecamatan_name'] = ucwords(strtolower($value['kecamatan_name']));
    }

    // Masukkan data ke dalam respons
    $response['wilayah'] = array_map(function ($item) {
        return [
            'id' => $item['id'],
            'kode' => $item['kode_kecamatan'],
            'nama' => $item['kecamatan_name']
        ];
    }, $query);
} else {
    // Jika query gagal
    $response['wilayah'] = [];
}

// Set header dan keluarkan JSON
header('Content-Type: application/json');

echo json_encode($response);

?>
