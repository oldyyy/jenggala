<?php
require_once 'config.php';
require_once 'helper_classes.php';

// Array for response data
$response = array();
$result = new Result();

// Check Login Status
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $kode_petugas = $_POST['kode_petugas'];

    if (empty($kode_petugas)) {
        $result->setError(true);
        $result->setMessage('Kode Petugas is required');
    } else {
        // Check if kode_petugas exists in the database
        $sql_plotting = "SELECT * FROM ploting_petugas WHERE kode_petugas = '$kode_petugas' ORDER BY id ASC";
        $query_plotting = $conn->query($sql_plotting);

        if ($query_plotting->num_rows > 0) {
            $response['plotting'] = array();
            while ($row_plotting = $query_plotting->fetch_assoc()) {

                // Ambil data kegiatan dari kd_kegiatan
                $kd_kegiatan = $row_plotting['kode_kegiatan'];
                $sql_master_kegiatan = "SELECT * FROM master_kegiatan WHERE kode_kegiatan = '$kd_kegiatan'";
                $query_master_kegiatan = $conn->query($sql_master_kegiatan);
                $row_master_kegiatan = $query_master_kegiatan->fetch_assoc();

                // Ambil info tabel responden dari kd_responden
                $kd_responden = $row_plotting['kode_responden'];
                $sql_master_responden = "SELECT * FROM master_responden WHERE kode_responden = '$kd_responden'";
                $query_master_responden = $conn->query($sql_master_responden);
                $row_master_responden = $query_master_responden->fetch_assoc();

                // Ambil info data responden dari tabel responden
                $sql_responden = "SELECT * FROM $row_master_responden[source_table] WHERE kode_responden = '$kd_responden'";
                $query_responden = $conn->query($sql_responden);
                $row_responden = $query_responden->fetch_assoc();

                // Ambil info prov - kabkot - kecamatan - keldes
                $sql_prov = "SELECT * FROM data_prov WHERE kode_prov = '$row_responden[kode_prov]'";
                $query_prov = $conn->query($sql_prov);
                $row_prov = $query_prov->fetch_assoc();
                $sql_kabkot = "SELECT * FROM data_kabkot WHERE kode_kabkot = '$row_responden[kode_kabkot]'";
                $query_kabkot = $conn->query($sql_kabkot);
                $row_kabkot = $query_kabkot->fetch_assoc();
                $sql_kecamatan = "SELECT * FROM data_kec WHERE kode_kecamatan = '$row_responden[kode_kecamatan]'";
                $query_kecamatan = $conn->query($sql_kecamatan);
                $row_kecamatan = $query_kecamatan->fetch_assoc();
                $sql_keldes = "SELECT * FROM data_keldes WHERE kode_keldes = '$row_responden[kode_keldes]'";
                $query_keldes = $conn->query($sql_keldes);
                $row_keldes = $query_keldes->fetch_assoc();


                // Ambil data tabel kategori
                $response['plotting']['kode_petugas'] = $kode_petugas;
                $response['plotting']['data_survei'][$kd_kegiatan]['nama_kegiatan'] = $row_master_kegiatan['kegiatan_name'];
                $response['plotting']['data_survei'][$kd_kegiatan]['responden'][] = array(
                    'id' => $row_plotting['id'],
                    'kode_responden' => $row_responden['kode_responden'],
                    'nama_perusahaan' => $row_responden['nama_perusahaan'],
                    'alamat_perusahaan' => ucwords(strtolower($row_responden['alamat_perusahaan'])),
                    'kode_prov' => ucwords(strtolower($row_prov['prov_name'])),
                    'kode_kabkot' => ucwords(strtolower($row_kabkot['kabkot_name'])),
                    'kode_kecamatan' => ucwords(strtolower($row_kecamatan['kecamatan_name'])),
                    'kode_keldes' => ucwords(strtolower($row_keldes['keldes_name'])),
                    'no_telepon' => $row_responden['no_telepon'],
                    'kode_status' => $row_responden['kode_status'],
                    'longitude' => $row_responden['longitude'],
                    'latitude' => $row_responden['lattitude'],
                );
            }

            $result->setError(false);
            $result->setMessage('Plotting retrieved successfully');
        } else {
            $response['plotting'] = array();
        }
    }

}
$response['result']['isError'] = $result->isError();
$response['result']['message'] = $result->getMessage();

echo json_encode($response); 
?>