<?php
class Result {
    private $isError;
    private $message;

    function isError() {
        return $this->isError;
    }

    function setError($isError) {
        $this->isError = $isError;
    }

    function getMessage() {
        return $this->message;
    }

    function setMessage($message) {
        $this->message = $message;
    }
}
?>