<?php
require_once 'config.php';
require_once 'helper_classes.php';

// Array for response data
$response = array();
$result = new Result();

// Check Login Status
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $username = $_POST['username'];
    $auth_token = $_POST['auth_token'];



    if (empty($username) || empty($auth_token)) {
        $result->setError(true);
        $result->setMessage('Username and auth token are required');
    } else {
        // Check if username exists in the database
        $sql = "SELECT * FROM login_petugas WHERE username = '$username' AND auth_token = '$auth_token'";
        $query = $conn->query($sql);

        if ($query->num_rows > 0) {
            $id_petugas = $query->fetch_assoc()['id'];

            $sql = "SELECT * FROM profil_petugas WHERE id = '$id_petugas'";
            $query = $conn->query($sql);

            if ($query->num_rows > 0) {
                $row = $query->fetch_assoc();

                $sql_kabkot = "SELECT * FROM data_kabkot WHERE kode_kabkot = '$row[kode_kabkot]'";
                $query_kabkot = $conn->query($sql_kabkot);
                $row_kabkot = $query_kabkot->fetch_assoc();

                $response['user']['username'] = $username;
                $response['user']['id'] = $row['id'];
                $response['user']['kode_petugas'] = $row['kode_petugas'];
                $response['user']['nama'] = $row['Nama_Petugas'];
                $response['user']['email'] = $row['email_petugas'];
                $response['user']['noHp'] = $row['no_petugas'];
                $response['user']['kabkot'] = ucwords(strtolower($row_kabkot['kabkot_name']));
                $response['user']['alamat'] = $row['alamat_petugas'];
                $response['user']['pengawas'] = $row['Pengawas'];

                $kode_petugas = $row['kode_petugas'];
               

                $result->setError(false);
                $result->setMessage('User info retrieved successfully');
            }
            else {
                $result->setError(true);
                $result->setMessage('User info not found');
            }
        } else {
            $result->setError(true);
            $result->setMessage('Invalid username or auth token');
        }
    }
} else {
    $result->setError(true);
    $result->setMessage('Invalid request method');
}

$response['result']['isError'] = $result->isError();
$response['result']['message'] = $result->getMessage();

echo json_encode($response); 