<?php
require_once 'config.php';
require_once 'helper_classes.php';

// Array for response data
$response = array();
$result = new Result();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the username and Password are empty
    if (empty($username) || empty($password)) {
        $result->setError(true);
        $result->setMessage('Username and Password are required');
    } else {

        // Check if username exists in the database
        $sql = "SELECT * FROM login_petugas WHERE username = '$username'";
        $query = $conn->query($sql);
        
        if ($query->num_rows > 0) {
            $row = $query->fetch_assoc();
            $db_password = $row['password'];

            // Verify the Password
            if (password_verify($password, $db_password)) {

                // Set authenticated token
                $auth_token = hash('sha256', $username . microtime());
                $sql = "UPDATE login_petugas SET auth_token = '$auth_token' WHERE username = '$username'";
                $conn->query($sql);

                $response['user']['username'] = $username;
                $response['user']['auth_token'] = $auth_token;

                $result->setError(false);
                $result->setMessage('Login successful');
            } else {
                $result->setError(true);
                $result->setMessage('Invalid Password');
            }
        } else {
            $result->setError(true);
            $result->setMessage('Invalid username');
        }
    }
} else {
    $result->setError(true);
    $result->setMessage('Invalid request method');
}

$response['result']['isError'] = $result->isError();
$response['result']['message'] = $result->getMessage();

echo json_encode($response);

    
