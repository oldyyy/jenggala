<?php
    $servername = "localhost";
    $username = "root";
    $Password = "";
    $dbname = "simovie_3";

    $conn = new mysqli($servername, $username, $Password, $dbname);
    if (!$conn) {
        echo "Failed to connect to MySQL: " . $conn->connect_error;
    }
?>